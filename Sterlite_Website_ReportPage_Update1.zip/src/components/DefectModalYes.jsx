import React from 'react';
import { useState } from 'react';
import "./componentscss/DefectModal.css";

function DefectModalYes({ onClose, onConfrim, identifier }) {

    const Defects = ["Patch", "Dent","Loose Wire", "Black Wire", "Others"];
    const [selectedDefect, setSelectedDefect] = useState();
    const [otherDefect, setOtherDefect] = useState();

    const handleSelectedDefect = (event) =>{
        setSelectedDefect(event.target.value);
        console.log(event.target.value);
    }

    const handleOtherDefect = (event) =>{
        setOtherDefect(event.target.value);
    }

    const handleConfirm = () =>{
        onConfrim(selectedDefect, otherDefect, identifier);
        onClose();
    }


  return (
    <div className='defect-modal-overlay'>
     <div className='defect-modal'>
        <div className='select-container'>
            <select className='select-modal' value={selectedDefect} onChange={handleSelectedDefect}>
                <option value="" hidden> Select Defect</option>
                {Defects.map((defect, index) =>(
                    <option className='select-option' key={index} value={defect}>
                        {defect}
                    </option>
                ))}
            </select>
        </div>
        
        {selectedDefect === "Others" && (
            <input
            className='ip-field'
            type="text"
            value={otherDefect}
            onChange={handleOtherDefect}
            placeholder="Enter defect..." />
        )}
        <div className="button-container-modal">
          <button className='ok' onClick={handleConfirm}>OK</button>
          <button className='cancel' onClick={onClose}>Cancel</button>
        </div>
     </div>
      
    </div>
  )
}

export default DefectModalYes;
