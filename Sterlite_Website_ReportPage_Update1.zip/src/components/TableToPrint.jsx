import React, { forwardRef,useEffect, useState, useCallback, useRef  } from 'react';
import './componentscss/Table.css';
import Toggle from './Toggle';
import YES from './YES';
import NO from './NO';
import "./componentscss/Toggle.css";
import { useReactToPrint } from 'react-to-print';

const TableToPrint = forwardRef((props, ref) =>{

    
    return (
        <div>
          
        </div>
      )
    });


 


export default TableToPrint
