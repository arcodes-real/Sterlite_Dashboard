const express = require('express');
const app = express();
const cors = require('cors');
const port = 8080;
const AWS = require('aws-sdk');

AWS.config.update({
    accessKeyId: 'AKIA24ADS5JH6NXSW3IR',
    secretAccessKey: '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',
    region: 'ap-south-1'
  });

  const s3 = new AWS.S3();

  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended : true }));

//   const shifts = {
//     shift1: {startTime: 7, endTime: 15},
//     shift2: { startTime: 15, endTime: 23 },
//     shift3: { startTime: 23, endTime: 7 }
//   }

  app.get('/image/:jetson/:date', (req, res) =>{
        const { jetson, date } = req.params;
        // const shiftInfo = shifts[shift];

        const bucketName = 'cvsterlite';
        // const timeString = `${shiftInfo.startTime}-${shiftInfo.endTime}`;

        const fileKey = `Sterlite_Deployment/dashboard/${jetson}/${date}/`;

        const params = {
            Bucket: bucketName,
            Key: fileKey,
            // ContentType: "application/json",
        };

        // Set CORS Headers

        res.header('Access-Control-Allow-Origin', '*');
        res.header(
            'Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept'
        );

        s3.getObject(params, (err, data) =>{
            if(err){
                console.error('Error fetching image:', err);
                res.status(404).json({ error: 'File not found' });
            } else{
                res.contentType(data.ContentType);
                res.send(data.Body);
            }
        });
  });

  app.get('/images/:jetson/:date', (req, res) =>{
    const { jetson, date } = req.params;
    const bucketName = 'cvsterlite';
    // const shiftInfo = shifts[shift];
    // const timeString = `${shiftInfo.startTime}-${shiftInfo.endTime}`;

    const prefix = `Sterlite_Deployment/dashboard/${jetson}/${date}/`;

    const params = {
        Bucket: bucketName,
        Prefix: prefix
    };

    s3.listObjectsV2(params, (err, data) =>{
        if(err){
            console.error('Error listing objects:', err);
            res.status(500).json({ error : 'Internal Server Error' });
        } else{
            const imageKeys = data.Contents.map(objects => objects.Key);
            res.json({ images: imageKeys });
        }
    });
  });

  app.listen(port, () =>{
    console.log(`Server running on port ${port}`);
  });

   









































// const { S3Client, GetObjectCommand, HeadObjectCommand, CopyObjectCommand} = require("@aws-sdk/client-s3");
// const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");


// // creating an instance of the AWS S3 service Client from the AWS SDK
// const s3Client =  new S3Client({
//     region: "ap-south-1",
//     credentials:{
//         accessKeyId: 'AKIA24ADS5JH6NXSW3IR',
//         secretAccessKey: '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'
//     },
// });

// async function getObjectURL(key){
//     const command = new GetObjectCommand({
//         Bucket: "cvsterlite",
//         Key: key,
//     });
//     const url = await getSignedUrl(s3Client, command);
//     return url;
// }

// // Content disposition typically refers to an HTTP header that provides information on how to handle the content
// // being transferred in a response. It's often used for specifying whether the content should be displayed inline in
// //  the browser or treated as an attachment.
// async function updateContentDisposition(key){
//     const headObjectCommand = new HeadObjectCommand({
//         Bucket: "cvsterlite",
//         Key: key,
//     });
//     try{
//         const { Metadata} = await s3Client.send(headObjectCommand);
//         Metadata["Content-Disposition"] = "inline";

//         const copyCommand = new CopyObjectCommand({
//             Bucket: "cvsterlite",
//             CopySource: "cvsterlite/"+ key,
//             Key: key,
//             MetadataDirective: "REPLACE",
//             Metadata: Metadata,
//             ContentType: "image/jpg",
//         });

//         await s3Client.send(copyCommand);
//         console.log("Content-Disposition updated for", key);
//     } catch(error){
//         console.error("Error updating Content-Disposition", error);
//     }
// }



// async function init(){
//     const key = "Sterlite_Deployment/dashboard/jetson1/2023-07-03//13-09-12_ROUND.jpg";
//     console.log("URL for first image:",await getObjectURL(key));
//     await updateContentDisposition(key);
//     // const contentType = "image/jpg";
//     // await uploadImageAndGenerateURL(key, contentType);
// }

// init();


// break

// const express = require('express');
// const app = express();
// const port = 7000;
// const cors = require('cors');
// const AWS = require('aws-sdk');

// AWS.config.update({
//     accessKeyId: 'AKIA24ADS5JH6NXSW3IR',
//     secretAccessKey: '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',
//     region: 'ap-south-1'
// });

// const s3 = new AWS.S3();

// app.use(cors());
// app.use(express.json());
// app.use(express.urlencoded({ extended:true }));

// app.get('/data/:date', (req, res) =>{

// })

// const params = {
//     Bucket: 'cvsterlite',
// }



// async function uploadImageAndGenerateURL(key, contentType){
//     const uploadCommand = new PutObjectAclCommand({
//         Bucket: "cvsterlite",
//         Key: key,
//         ACL: "public-read",
//         ContentType: "image/jpg",
//     });

//     try{
//         await s3Client.send(uploadCommand);
//         console.log("image uploaded successfully");

//         const signedURL = await getSignedUrl(s3Client, {
//             command: new GetObjectCommand({
//                 Bucket: "cvsterlite",
//                 Key: key,
                
//             }),
//             expiresIn: 3600,
//         });
//         console.log("Signed URL:", signedURL );
//     } catch(err){
//         console.error("Error uploading image:",err);
//     }
// }