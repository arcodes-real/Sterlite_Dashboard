import React from 'react';
import { useState } from 'react';
import DefectModal from './DefectModal';
import "./componentscss/YES.css";

function YES() {

    // const [modalOpen, setModalOpen] = useState(false);
    // const [selectedDefect, setSelectedDefect] = useState('');
    // const [otherDefect, setOtherDefect] = useState('');

    //   const openModal = () => {
    //     setModalOpen(true);
    //   };
    
    //   const closeModal = () => {
    //     setModalOpen(false);
    //   };
    
    //   const handleConfirm = (defect, other) => {
    //     setSelectedDefect(defect);
    //     setOtherDefect(other);
    //   };



  return (
    <div>
      <button className='yes'>YES</button> 
      {/* {modalOpen && (
        <DefectModal onClose={closeModal} onConfrim={handleConfirm} />
      )}
      {selectedDefect && (
        <div>
            Selected Defect:{selectedDefect}
            {selectedDefect === "Others" && (
                <div>Other Defect:{otherDefect}</div>
            )}
        </div>
      )} */}
    </div>
  )
}

export default YES;

/*onClick={openModal}*/