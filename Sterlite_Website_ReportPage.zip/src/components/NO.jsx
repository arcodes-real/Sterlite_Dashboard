import React from 'react';
import "./componentscss/NO.css";

function NO() {
  return (
    <div>
      <button className='no'>NO</button>
    </div>
  )
}

export default NO;
