import React, { useEffect, useState, useCallback } from 'react';
import './componentscss/Table.css';
import Toggle from './Toggle';
import YES from './YES';
import NO from './NO';
import "./componentscss/Toggle.css";
// import { useSelectedCage } from './SelectedCageContext';



export default function Table({ selectedDate, selectedCage, setSelectedCage, formattedDate, setFormattedDate, selectedShift }) {

// state and setState function to store and update state respectively. imgURLs store the array of image urls.    
    const [imgURLs, setImgURLs] = useState([]);
    const [filteredImageURLs, setFilteredImageURLs] = useState([]);
    
// triggers when the component first mounts, to display today's(current date's) data, with cage 24 as default 
// setting the initial state of the formattedDate to todays date   
    useEffect(() => {
        const currentDate = new Date();
        const todayYear = currentDate.getFullYear();
        const todayMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // padding required to match format with backend  
        const todayDay = (currentDate.getDate()).toString().padStart(2, '0');  // padding required to match format with backend
    
        const todayDate = `${todayYear}-${todayMonth}-${todayDay}`;
    
        setFormattedDate(todayDate);
    }, []);
    
    
    const fetchImgURLs = useCallback(async() =>{
        try{
            let imageUrl = '';
            let imageUrls = []; // array to store image urls from all cages

            if(selectedCage === "All"){
                    const listDevices = ["jetson1", "jetson2","jetson3"];
                    for(let device of listDevices){
                        imageUrl =`http://localhost:8080/images/${device}/${formattedDate}/`;
                        const response = await fetch(imageUrl);
                        const data = await response.json();
                        const filteredImages = data.images.filter(image => !image.endsWith('/'));
                        imageUrls = imageUrls.concat(filteredImages);
                    }
                    console.log(imageUrls);
                    
                
                
            } else{
                const jetsonName = selectedCage === "Cage 12" ? "jetson1" : selectedCage === "Cage 18" ? "jetson2" : "jetson3";
                console.log(jetsonName);
                // imageUrl = `http://192.168.1.101:8080/images/${jetsonName}/${formattedDate}/`;
                imageUrl = `http://localhost:8080/images/${jetsonName}/${formattedDate}/`;
                const response = await fetch(imageUrl);
                const data = await response.json();
                const filteredImages = data.images.filter(image => !image.endsWith('/'));
                imageUrls = filteredImages;
                // console.log(imageUrl);
            }
            
            
            setImgURLs(imageUrls);

        } catch(error){
            console.error("Error Fetching Images", error);
        }
    }, [selectedCage, formattedDate]);
    

// triggers fetchimgURLs function
    useEffect(() =>{
            if (formattedDate && formattedDate !== 'undefined') {
                fetchImgURLs();
            }
        },[formattedDate,fetchImgURLs]);


// function to filter images based on shift
        const filterImagesByShift = useCallback(() =>{
            if(!selectedShift || selectedShift === "All") { 
                setFilteredImageURLs(imgURLs);
                return;
            }
                const shiftStartTimes = {
                "Shift 1" : 7,
                "Shift 2" : 15,
                "Shift 3" : 23
            };
            const selectedShiftStartHour = shiftStartTimes[selectedShift];
            console.log(selectedShiftStartHour);
            const selectedShiftEndHour = (selectedShiftStartHour + 8) % 24;

            const filteredImages = imgURLs.filter((imgURL) =>{
                const Imgparts = imgURL.split("/");
                const ImgfileName = Imgparts[Imgparts.length - 1];
                const Imgtimestamp = ImgfileName.split("_")[0].split("-").slice(-3).join(":");
                console.log(Imgtimestamp);

                const hour = parseInt(Imgtimestamp.split(":")[0]);
                console.log(hour);
                console.log(selectedShiftStartHour);
                if (selectedShiftStartHour < selectedShiftEndHour) {
                    return hour >= selectedShiftStartHour && hour < selectedShiftEndHour;
                } else {
                    // Handle the case where the shift spans across midnight
                    return hour >= selectedShiftStartHour || hour < selectedShiftEndHour;
                }
            });
            console.log("Filtered Images:", filteredImages);
            setFilteredImageURLs(filteredImages);
             }, [imgURLs, selectedShift]);

        useEffect(() =>{
            filterImagesByShift();
        }, [filterImagesByShift]);

        const cageNameMappings = {
            jetson1: "Cage 12",
            jetson2: "Cage 18",
            jetson3: "Cage 24"
          };
        
        
return (
    <div className='table-container'>
        <table className='table'>
            <thead>
            <tr>
                <th>DATE</th>
                <th>TIME</th>
                <th>CAGE</th>
                <th>VERIFY</th>
                <th>IMAGE</th>
            </tr>
                
            </thead>
            <tbody>
            {filteredImageURLs.map((imgURL, index) => {
                const parts = imgURL.split("/");
                const fileName = parts[parts.length - 1]; // Get the last part of the URL

                // Extract the timestamp from the file name
                const timestamp = fileName.split("_")[0].split("-").slice(-3).join(":");

                // Extract the corresponding Cage name from the file name

                const cageNameFromUrl = imgURL.split("/")[2];
                const cageName = cageNameMappings[cageNameFromUrl];
                

                return (
                <tr key={index}>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">{timestamp}</td>
                    <td datalabel="CAGE">
                    {selectedCage === "All" ? cageName : selectedCage !== ""? selectedCage : "No Cage Seledted"}
                    </td>
                    <td datalabel="VERIFY">
                    <div className='verify-buttons'>
                    <YES />
                    <NO />
                    </div>
                    </td>
                    <td datalabel="IMAGE">
                    <img src={`https://cvsterlite.s3.ap-south-1.amazonaws.com/${imgURL}`} alt="No_Image_Available" />
                    </td>
                </tr>
                );
            })}
            </tbody>
        </table>
      
    </div>
  )
}



                /* <tr>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">12.15</td>
                    <td datalabel="DEFECT TYPE">{selectedCage !== "" ? selectedCage : "No Cage Selected"}</td>
                    <td datalabel="VERIFY">
                        <Toggle />
                    </td>
                    <td datalabel="IMAGE">{imgURl? <img src={imgURl} alt="Defect_Image" /> : "No Image"}</td>
                </tr>

                <tr>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">13.00</td>
                    <td datalabel="DEFECT TYPE">{selectedCage !== "" ? selectedCage : "No Cage Selected"}</td>
                    <td datalabel="VERIFY">
                        <Toggle  />
                    </td>
                    <td datalabel="IMAGE">{imgURl? <img src={imgURl} alt="Defect_Image" /> : "No Image"}</td>
                </tr>

                <tr>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">16.15</td>
                    <td datalabel="DEFECT TYPE">{selectedCage !== "" ? selectedCage : "No Cage Selected"}</td>
                    <td datalabel="VERIFY">
                        <Toggle  />
                    </td>
                    <td datalabel="IMAGE">{imgURl? <img src={imgURl} alt="Defect_Image" /> : "No Image"}</td>
                </tr>

                <tr>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">18.40</td>
                    <td datalabel="DEFECT TYPE">{selectedCage !== "" ? selectedCage : "No Cage Selected"}</td>
                    <td datalabel="VERIFY">
                        <Toggle />
                    </td>
                    <td datalabel="IMAGE">{imgURl? <img src={imgURl} alt="Defect_Image" /> : "No Image"}</td>
                </tr>

                <tr>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">20.00</td>
                    <td datalabel="DEFECT TYPE">{selectedCage !== "" ? selectedCage : "No Cage Selected"}</td>
                    <td datalabel="VERIFY">
                        <Toggle />
                    </td>
                    <td datalabel="IMAGE">{imgURl? <img src={imgURl} alt="Defect_Image" /> : "No Image"}</td>
                </tr>

                <tr>
                    <td datalabel="DATE">{selectedDate.toLocaleDateString()}</td>
                    <td datalabel="TIME">23.00</td>
                    <td datalabel="DEFECT TYPE">{selectedCage !== "" ? selectedCage : "No Cage Selected"}</td>
                    <td datalabel="VERIFY">
                        <Toggle />
                    </td>
                    <td datalabel="IMAGE">{imgURl? <img src={imgURl} alt="Defect_Image" /> : "No Image"}</td>
                </tr> */



                // useEffect(() =>{
    //     const currentDate = new Date();
    //     const todayYear = currentDate.getFullYear();
    //     const todayMonth = currentDate.getMonth() + 1;
    //     const todayDay = currentDate.getDate();

    //     const todayDate = `${todayYear}-${todayMonth}-${todayDay}`;

    //     setFormattedDate(todayDate);
    // }, []);

    // useEffect(() =>{
    //     fetchImgURLs(formattedDate);
    // }, [formattedDate]);

    // useEffect(() =>{
    //     const initialCage = "Cage 24";
    //     setSelectedCage(initialCage);
    // }, [setSelectedCage])

    // useEffect(() =>{
    //     fetchImgURLs(selectedCage);
    // }, [selectedCage]);